"""
This file is part of the tasks for the Adding 2 integers task. It is part of the tasks/projects carried out in 
the I4GxZuri Scholarship in the Fullstack Track.


Author: Mudassir Adili Ahmad (adilimudassir)
Date: 2022-05-16
"""

#num variables
num1 = 2;
num2 = 3;

print(num1 + num2);